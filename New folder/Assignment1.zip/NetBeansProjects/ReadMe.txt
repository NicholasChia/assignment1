INN 374 Assignment 1

Student Name : Vincent Lim Tzit Xiang
Student ID : N7387512
Student Name : Nicholas Chia Jin Chao
Student ID : N7307853 

Statement of completeness:
We have completed all the required parts stated in the assignment specs. however we did not used the lastest provided version of the Ciruit Componetnts, We used the 3rd version. There is not any known bugs
or deficiencies in the code.