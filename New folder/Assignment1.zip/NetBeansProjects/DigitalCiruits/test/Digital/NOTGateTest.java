/**
 *@file NOTGateTest.java
 *@date 27/08/12
 *@author Vincent Lim Tzit Xiang N7387512
 *@author Nicholas Chia Jin Chao N7307853
 *@version 1.0
 *@brief The implementation of NOT Gate Unit Testing.  Code is modified from ANDGateTest.
 */

package Digital;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class NOTGateTest {
    
    private NOTGate instance;  
    private TestTerminal input0, input1;    
    
    @Before
    public void setUp() {
        instance = new NOTGate();      
        input0 = new TestTerminal();
        input1 = new TestTerminal();         
    }
    
    @Test
    public void testOutput() { 
        Terminal output = instance.getOutput();
        assertTrue(output != null);
        assertTrue(output.getClass() == OutputTerminal.class);  
    }         
    
    @Test
    public void testInput() {
        instance.setInput(input0);
        Terminal result = instance.getInput();
        assertEquals("get Input should return the Terminal set by setInput", input0, result);
    }   

    @Test
    public void testTrue() {
        input0.setValue(true);
        instance.setInput(input0);
        assertEquals("true should generate false", false, instance.getOutput().getValue());
    }
    
    @Test
    public void testFalse() {
        input0.setValue(false);
        instance.setInput(input0);
        assertEquals("false should generate true", true, instance.getOutput().getValue());
    }
    
    @Test
    public void testNoInput() {
        assertEquals("if input is not connected then that input value should be treated as false", false, instance.getOutput().getValue());
    }  
    
    @Test
    public void testInputValueChanged() {
        input0.setValue(true);
        instance.setInput(input0);
        assertEquals(instance.getOutput().getValue(), false);
        
        input0.setValue(false);
        assertEquals("if the value of input changes then the output of the NOT gate needs to be recomputed", true, instance.getOutput().getValue());        
    }    
    
    @Test
    public void testInputChanged() {
        input0.setValue(true);
        input1.setValue(false);
        instance.setInput(input0);
        assertEquals(instance.getOutput().getValue(), false);
        
        instance.setInput(input1);
        assertEquals("if Input is connected to a different output terminal then the output of the NOT gate needs to be recomputed", true, instance.getOutput().getValue());        
    }   
    
    @Test
    public void testInputCleared() {
        input0.setValue(true);
        instance.setInput(input0);
        assertEquals(instance.getOutput().getValue(), false);
        
        instance.setInput(null);
        assertEquals("if Input is disconnected then the output of the NOT gate needs to be recomputed", false, instance.getOutput().getValue());        
    }     
}

/**
 *@class NOTGateTest NOTGateTest.java "Digital/NOTGateTest.java"
 *@brief The implementation of NOT Gate Unit Testing.
 *
 */