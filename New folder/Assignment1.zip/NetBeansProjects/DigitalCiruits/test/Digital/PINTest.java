/**
 *@file PINGateTest.java
 *@date 27/08/12
 *@author Vincent Lim Tzit Xiang N7387512
 *@author Nicholas Chia Jin Chao N7307853
 *@version 1.0
 *@brief The implementation of PIN Gate Unit Testing.  Code is modified from ANDGateTest provided.
 */

package Digital;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class PINTest {
    
    private PIN instance;  
    private TestTerminal input0, input1;    
    
    @Before
    public void setUp() {
        instance = new PIN();      
        input0 = new TestTerminal();
        input1 = new TestTerminal();         
    }
    
    @Test
    public void testOutput() { 
        Terminal output = instance.getOutput();
        assertTrue(output != null);
        assertTrue(output.getClass() == OutputTerminal.class);  
    }         
    
    @Test
    public void testInput() {
        instance.setInput(input0);
        Terminal result = instance.getInput();
        assertEquals("get Input should return the Terminal set by setInput", input0, result);
    }   

    @Test
    public void testTrue() {
        input0.setValue(true);
        instance.setInput(input0);
        assertEquals("true should generate true", true, instance.getOutput().getValue());
    }
    
    @Test
    public void testFalse() {
        input0.setValue(false);
        instance.setInput(input0);
        assertEquals("false should generate false", false, instance.getOutput().getValue());
    }
    
    @Test
    public void testNoInputs() {
        assertEquals("if the input is not connected then that input value should be treated as false", false, instance.getOutput().getValue());
    }  
    
    @Test
    public void testInputValueChanged() {
        input0.setValue(true);
        instance.setInput(input0);
        assertEquals(instance.getOutput().getValue(), true);
        
        input0.setValue(false);
        assertEquals("if the value of input changes then the output of the PIN gate needs to be recomputed", false, instance.getOutput().getValue());        
    }    
    
    @Test
    public void testInputChanged() {
        input0.setValue(true);
        input1.setValue(false);
        instance.setInput(input0);
        assertEquals(instance.getOutput().getValue(), true);
        
        instance.setInput(input1);
        assertEquals("if Input is connected to a different output terminal then the output of the PIN gate needs to be recomputed", false, instance.getOutput().getValue());        
    }   
    
    @Test
    public void testInputCleared() {
        input0.setValue(true);
        instance.setInput(input0);
        assertEquals(instance.getOutput().getValue(), true);
        
        instance.setInput(null);
        assertEquals("if Input is disconnected then the output of the PIN gate needs to be recomputed", false, instance.getOutput().getValue());        
    }    
}

/**
 *@class PINGateTest PINGateTest.java "Digital/PINGateTest.java"
 *@brief The implementation of PIN Gate Unit Testing.
 *
 */