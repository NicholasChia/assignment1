/**
 *@file ORGateTest.java
 *@date 27/08/12
 *@author Vincent Lim Tzit Xiang N7387512
 *@author Nicholas Chia Jin Chao N7307853
 *@version 1.0
 *@brief The implementation of OR Gate Unit Testing.  Code is modified from ANDGateTest.
 */

package Digital;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;


public class ORGateTest 
{
    private ORGate instance;  
    private TestTerminal input0, input1, input2;    
    
    @Before
    public void setUp() {
        instance = new ORGate();      
        input0 = new TestTerminal();
        input1 = new TestTerminal();   
        input2 = new TestTerminal();         
    }
    
    @Test
    public void testOutput() { 
        Terminal output = instance.getOutput();
        assertTrue(output != null);
        assertTrue(output.getClass() == OutputTerminal.class);  
    }         
    
    @Test
    public void testInput0() {
        instance.setInput0(input0);
        Terminal result = instance.getInput0();
        assertEquals("get input0 should return the Terminal set by setInput0", input0, result);
    }    
    
    @Test
    public void testInput1() {
        instance.setInput1(input1);
        Terminal result = instance.getInput1();
        assertEquals("get input1 should return the Terminal set by setInput1", input1, result);
    }    
    
    @Test
    public void testBothTrue() {
        input0.setValue(true);
        input1.setValue(true);
        instance.setInput0(input0);
        instance.setInput1(input1);
        assertEquals("true AND true should generate true", true, instance.getOutput().getValue());
    }
    
    @Test
    public void testTrueAndFalse() {
        input0.setValue(true);
        input1.setValue(false);
        instance.setInput0(input0);
        instance.setInput1(input1);
        assertEquals("true AND false should generate true", true, instance.getOutput().getValue());
    }
    
    @Test
    public void testFalseAndTrue() {
        input0.setValue(false);
        input1.setValue(true);
        instance.setInput0(input0);
        instance.setInput1(input1);
        assertEquals("false AND true should generate true", true, instance.getOutput().getValue());
    }
    
    @Test
    public void testBothFalse() {
        input0.setValue(false);
        input1.setValue(false);
        instance.setInput0(input0);
        instance.setInput1(input1);
        assertEquals("false AND false should generate false", false, instance.getOutput().getValue());
    }     
  
    @Test
    public void testNoInputs() {
        assertEquals("if one of the inputs is not connected then that input value should be treated as false", false, instance.getOutput().getValue());
    }      
    
    @Test
    public void testInput0ValueChanged() {
        input0.setValue(true);
        input1.setValue(true);
        instance.setInput0(input0);
        instance.setInput1(input1);
        assertEquals(instance.getOutput().getValue(), true);
        
        input0.setValue(false);
        assertEquals("if the value of input0 changes then the output of the OR gate needs to be recomputed", true, instance.getOutput().getValue());        
    }    
    
    @Test
    public void testInput0Changed() {
        input0.setValue(true);
        input1.setValue(true);
        input2.setValue(false);
        instance.setInput0(input0);
        instance.setInput1(input1);
        assertEquals(instance.getOutput().getValue(), true);
        
        instance.setInput0(input2);
        assertEquals("if input0 is connected to a different output terminal then the output of the OR gate needs to be recomputed", true, instance.getOutput().getValue());        
    }   
    
    @Test
    public void testInput0Cleared() {
        input0.setValue(true);
        input1.setValue(true);
        instance.setInput0(input0);
        instance.setInput1(input1);
        assertEquals(instance.getOutput().getValue(), true);
        
        instance.setInput0(null);
        assertEquals("if input0 is disconnected then the output of the OR gate needs to be recomputed", false, instance.getOutput().getValue());        
    }     
    
    @Test
    public void testInput1ValueChanged() {
        input0.setValue(true);
        input1.setValue(true);
        instance.setInput0(input0);
        instance.setInput1(input1);
        assertEquals(instance.getOutput().getValue(), true);
        
        input1.setValue(false);
	assertEquals("if the value of input1 changes then the output of the OR gate needs to be recomputed", true, instance.getOutput().getValue());
    }    
    
    @Test
    public void testInput1Changed() {
        input0.setValue(true);
        input1.setValue(true);
        input2.setValue(false);
        instance.setInput0(input0);
        instance.setInput1(input1);
        assertEquals(instance.getOutput().getValue(), true);
        
        instance.setInput1(input2);
        assertEquals("if input0 is connected to a different output terminal then the output of the OR gate needs to be recomputed", true, instance.getOutput().getValue());        
    } 
    
    @Test
    public void testInput1Cleared() {
        input0.setValue(true);
        input1.setValue(true);
        instance.setInput0(input0);
        instance.setInput1(input1);
        assertEquals(instance.getOutput().getValue(), true);
        
        instance.setInput1(null);
        assertEquals("if input1 is disconnected then the output of the OR gate needs to be recomputed", false, instance.getOutput().getValue());        
    }
}

/**
 *@class ORGateTest ORGateTest.java "Digital/ORGateTest.java"
 *@brief The implementation of OR Gate Unit Testing.
 *
 */