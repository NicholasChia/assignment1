/**
 *@file XORGate.java
 *@date 22/08/12
 *@author Vincent Lim Tzit Xiang N7387512
 *@author Nicholas Chia Jin Chao N7307853
 *@version 1.0
 *@brief The implementation of XOR Gate.  Code is modified from ANDGate.
 */

package Digital;

public class XORGate extends BinaryGates {
    
    public XORGate() {
       super("images/XOR.gif");
    }
    
    /*Overriding the compute function which will return the change value*/
    @Override
    protected boolean Compute(boolean a, boolean b){
        return a^b;
    }
}      

/**
 *@class XORGate XORGate.java "Digital/XORGate.java"
 *@brief The implementation of XOR Gate.
 *
 */