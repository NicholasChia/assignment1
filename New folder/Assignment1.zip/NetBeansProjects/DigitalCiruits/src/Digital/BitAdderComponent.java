/**
 *@file BitAdderComponent.java
 *@date 25/08/12
 *@author Vincent Lim Tzit Xiang N7387512
 *@author Nicholas Chia Jin Chao N7307853
 *@version 1.0
 *@brief The implementation of Bit Adder Component.  Code is modified from Assignment Specification provided.
 */

package Digital;

import java.awt.Image;
import javax.swing.JPanel;

public class BitAdderComponent extends JPanel {

    /*Initalising Variables */
    private final Image image;
    private Terminal Input0;
    private Terminal Input1;
    private Terminal Input2;
    private BitAdderCircuit adder = new BitAdderCircuit();
    private OutputTerminal Output0 = new OutputTerminal();
    private OutputTerminal Output1 = new OutputTerminal();
    
    /*a constructor*/
    public BitAdderComponent() {
        java.net.URL url = getClass().getResource("images/Adder.gif");
        image = new javax.swing.ImageIcon(url).getImage();
        this.setSize(image.getWidth(null), image.getHeight(null));
    }

    /*getter methods */
    public Terminal getInput0(){
        return adder.getPin1().getInput();
    }

    public Terminal getInput1() {
        return adder.getPin2().getInput();
    }
    public Terminal getInput2() {
        return adder.getPin3().getInput();
    }
    
    public Terminal getOutput0() {
        return adder.getPin4().getOutput();
    }
    
    public Terminal getOutput1() {
        return adder.getPin5().getOutput();
    }

    /*setter methods */
    public void setInput0(Terminal input) {
        adder.getPin1().setInput(input);
    }

    public void setInput1(Terminal input) {
        adder.getPin2().setInput(input);
    }
    
    public void setInput2(Terminal input) {
        adder.getPin3().setInput(input);
    }

    /*overriding the paintComponent function to display the image provided in the constructor*/
    @Override
    public void paintComponent(java.awt.Graphics g) {
        g.drawImage(image, 0,0, null);
    }   
}

/**
 *@class BitAdderComponent BitAdderComponent.java "Digital/BitAdderComponent.java"
 *@brief The implementation of Bit Adder Component.
 *
 */