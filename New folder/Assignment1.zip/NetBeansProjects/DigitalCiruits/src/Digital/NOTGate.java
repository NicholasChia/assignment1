/**
 *@file NOTGate.java
 *@date 22/08/12
 *@author Vincent Lim Tzit Xiang N7387512
 *@author Nicholas Chia Jin Chao N7307853
 *@version 1.0
 *@brief The implementation of NOT Gate.  Code is modified from ANDGate.
 */

package Digital;

public class NOTGate extends UnaryGates {
    
    public NOTGate() {
        super("images/NOT.gif");
    }
    
    /*Overriding the compute function which will return the change value*/
    @Override
    protected boolean Compute(boolean a) {
        return (!a);
    }       
}      

/**
 *@class NOTGate NOTGate.java "Digital/NOTGate.java"
 *@brief The implementation of NOT Gate.
 *
 */