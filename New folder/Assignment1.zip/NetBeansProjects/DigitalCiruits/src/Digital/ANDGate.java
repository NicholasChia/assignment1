/**
 *@file ANDGate.java
 *@date 22/08/12
 *@author Vincent Lim Tzit Xiang N7387512
 *@author Nicholas Chia Jin Chao N7307853
 *@version 1.0
 *@brief The implementation of AND Gate.  Code is from Assignment Specification provided.
 */

package Digital;

public class ANDGate extends BinaryGates {
    
    public ANDGate() {
       super("images/AND.gif");
    }
    
    /*Overriding the compute function which will return the change value*/
    @Override
    protected boolean Compute(boolean a, boolean b) {
        return (a&&b);
    }
}

/**
 *@class ANDGate ANDGate.java "Digital/ANDGate.java"
 *@brief The implementation of AND Gate.
 *
 */
