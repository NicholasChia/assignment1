/**
 *@file ORGate.java
 *@date 22/08/12
 *@author Vincent Lim Tzit Xiang N7387512
 *@author Nicholas Chia Jin Chao N7307853
 *@version 1.0
 *@brief The implementation of OR Gate.  Code is modified from ANDGate.
 */


package Digital;

public class ORGate extends BinaryGates {
    
    public ORGate() {
       super("images/OR.gif");
    }
    
    
    /*Overriding the compute function which will return the change value*/
    @Override
    protected boolean Compute(boolean a, boolean b) {
        return (a||b);
    }
} 

/**
 *@class ORGate ORGate.java "Digital/ORGate.java"
 *@brief The implementation of OR Gate.
 *
 */
