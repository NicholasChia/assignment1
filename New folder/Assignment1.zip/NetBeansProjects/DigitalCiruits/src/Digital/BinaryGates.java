/**
 *@file BinaryGates.java
 *@date 23/08/12
 *@author Vincent Lim Tzit Xiang N7387512
 *@author Nicholas Chia Jin Chao N7307853
 *@version 1.0
 *@brief The implementation of Binary Gates.  Code is modified from Assignment Specification provided.
 */

package Digital;

import java.awt.Graphics;
import java.awt.Image;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JPanel;

public class BinaryGates extends JPanel implements PropertyChangeListener {
    
    /*Initalising the variables*/
    protected final Image image;
    protected Terminal input0;
    protected Terminal input1;
    protected OutputTerminal output = new OutputTerminal();

    /*A constructor with a parameter of type String*/ 
    public BinaryGates(String imageURL) {
        java.net.URL url = getClass().getResource(imageURL);
        image = new javax.swing.ImageIcon(url).getImage();
        this.setSize(image.getWidth(null), image.getHeight(null));
    }

    public Terminal getInput0() {
        return input0;
    }

    public Terminal getInput1() {
        return input1;
    }

    public Terminal getOutput() {
        return output;
    }
    
    /*setter method
     *It will only add a property change listener if the input is not null and
     *will call the recomputeOutput function whenever there is a change
     * in value
     */
    public void setInput0(Terminal input) {
        this.input0 = input;
        if (getInput0() != null) {
            input0.addPropertyChangeListener(this);
        }
        recomputeOutput();
    }

    public void setInput1(Terminal input) {
        this.input1 = input;
        if (getInput1() != null) {
            input1.addPropertyChangeListener(this);
        }
        recomputeOutput();
    }

    /*overriding the paintComponent function to display the image provided in the constructor*/
    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(image, 0, 0, null);
    }

    /* overriding the propertyChange function to call the recomputeOutput function
     * whenever there is a change in inputs
     */
    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        recomputeOutput();
    }
    
    /* a function to compute the 2 parameters given and return as a boolean*/
    protected boolean Compute(boolean a, boolean b) {
        return a&&b;
    }

    /*a function to recompute the output whenever is it called and will set
     * the output value as false if either of the inputs is null
     */
    public void recomputeOutput() {
        if (getInput0() == null || getInput1() == null) {
            output.setValue(false);
        } 
        else {
            if (Compute((input0.getValue()) , (input1.getValue())) == true) {
                output.setValue(true);
            } 
            else {
                output.setValue(false);
            }
        }
    }
}

/**
 *@class BinaryGates BinaryGates.java "Digital/BinaryGates.java"
 *@brief The implementation of Binary Gates.
 *
 */