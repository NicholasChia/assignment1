/**
 *@file UnaryGates.java
 *@date 23/08/12
 *@author Vincent Lim Tzit Xiang N7387512
 *@author Nicholas Chia Jin Chao N7307853
 *@version 1.0
 *@brief The implementation of Unary Gates.  Code is modified from ANDGate.
 */

package Digital;

import java.awt.Graphics;
import java.awt.Image;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JPanel;

public abstract class UnaryGates extends JPanel implements PropertyChangeListener {
    
    /*Initalising Variables */
    protected final Image image;
    protected Terminal input;
    protected OutputTerminal output = new OutputTerminal();

    /*a constructor with a parameter of type String*/
    public UnaryGates(String imageURL) {
        java.net.URL url = getClass().getResource(imageURL);
        image = new javax.swing.ImageIcon(url).getImage();
        this.setSize(image.getWidth(null), image.getHeight(null));
    }

    public Terminal getInput() {
        return input;
    }

    public Terminal getOutput() {
        return output;
    }

    /*setter method
     *It will only add a property change listener if the input is not null and
     *will call the recomputeOutput function whenever there is a change
     * in value
     */
    public void setInput(Terminal input) {
        this.input = input;
        if (getInput() != null) {
            input.addPropertyChangeListener(this);
        } 
        recomputeOutput();
    }
    
    /*overriding the paintComponent function to display the image provided in the constructor*/
    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(image, 0, 0, null);
    }

     /* overriding the propertyChange function to call the recomputeOutput 
      * function whenever there is a change in the input
     */
    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        recomputeOutput();
    }

    /* a function to compute the parameter given and return as a boolean*/
    protected boolean Compute(boolean a) {
        return true;
    }
    
    /*a function to recompute the output whenever is it called and will set
     * the output value as false if the input is null
     */
    public void recomputeOutput() {
        if (getInput() == null) {
            output.setValue(false);
        } else {
                if ((Compute(input.getValue())) == true) {
                    output.setValue(true);
                } 
                else {
                    output.setValue(false);
                }
            }
    }
}

/**
 *@class UnaryGates UnaryGates.java "Digital/UnaryGates.java"
 *@brief The implementation of Unary Gates.
 *
 */