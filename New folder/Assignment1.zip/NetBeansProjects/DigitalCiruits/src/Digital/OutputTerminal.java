/**
 *@file OutputTerminal.java
 *@date 22/08/12
 *@author Vincent Lim Tzit Xiang N7387512
 *@author Nicholas Chia Jin Chao N7307853
 *@version 1.0
 *@brief The implementation of Output Terminal.  Code is modified from Assignment Specification provided.
 */


package Digital;

import java.beans.*;

public class OutputTerminal implements Terminal {
    
    /*Initalising Variables */
    private transient final PropertyChangeSupport vPcs = new PropertyChangeSupport(this);
    private boolean value = false;
   
    @Override
    public boolean getValue() {
        return value;
    }
    
    public void setValue(boolean val) {
        boolean oldValue = value;
        value = val;
        vPcs.firePropertyChange("Value", oldValue, val);
    }
    
    @Override
     public void addPropertyChangeListener(PropertyChangeListener listener) {
        vPcs.addPropertyChangeListener(listener);
     }
    
    @Override
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        vPcs.removePropertyChangeListener(listener);
    }  
}

/**
 *@class OutputTerminal OutputTerminal.java "Digital/OutputTerminal.java"
 *@brief The implementation of Output Terminal.
 *
 */