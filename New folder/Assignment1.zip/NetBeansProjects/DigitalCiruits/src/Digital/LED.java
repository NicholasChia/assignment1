/**
 *@file LED.java
 *@date 22/08/12
 *@author Vincent Lim Tzit Xiang N7387512
 *@author Nicholas Chia Jin Chao N7307853
 *@version 1.0
 *@brief The implementation of LED.  Code is modified from Assignment Specification provided.
 */

package Digital;

import java.awt.Graphics;
import java.awt.Image;
import java.beans.PropertyChangeEvent;  
import java.beans.PropertyChangeListener;
import javax.swing.JPanel;

public class LED extends JPanel implements PropertyChangeListener {
    
    /*Initalising the variables*/
    private final Image LedOn;
    private final Image LedOff;
    private Terminal input;

    public LED() {
        java.net.URL url = getClass().getResource("images/LED_on.gif");
        LedOn = new javax.swing.ImageIcon(url).getImage();
        this.setSize(LedOn.getWidth(null), LedOn.getHeight(null));
        
        url  = getClass().getResource("images/LED_off.gif");
        LedOff = new javax.swing.ImageIcon(url).getImage();
        this.setSize(LedOff.getWidth(null), LedOff.getHeight(null));
    }
    
    public Terminal getInput() {
        return input;
    }
    
    /*setter method
     *It will only add a property change listener if the input is not null and
     *will call the repaint function whenever there is a change
     * in value
     */
    public void setInput(Terminal input) {
        this.input = input;
        if(getInput()!=null) {
            input.addPropertyChangeListener(this);
        }
        repaint();        
    }
    
    /*overriding the propertychange method and repainting each time there is a
     * change in input
     */
    @Override
    public void propertyChange(PropertyChangeEvent evt) {   
        repaint();
    }
    
    /*repaint function to change the image that is being display*/
    public void repaint(Graphics g) {
       paintComponent(g);
    }

    /* overriding the paintComponent function to allow the displaying of 
     * different images whenever there is a change in input
     */
    @Override
    public void paintComponent(java.awt.Graphics g) { 
        if(getInput() == null) {
           g.drawImage(LedOff, 0,0, null);
        }   
        else {
            if((input.getValue()==true)) {
                g.drawImage(LedOn, 0,0, null);
            }
        
            if((input.getValue()==false)) {
                g.drawImage(LedOff, 0,0, null);
            }
        }  
    }
}

/**
 *@class LED LED.java "Digital/LED.java"
 *@brief The implementation of LED.
 *
 */